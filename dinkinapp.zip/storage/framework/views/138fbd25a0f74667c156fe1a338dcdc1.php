<div class="mt-3 mb-3">
    <form action="<?php echo e($formAction); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <div class="input-group w-50">

            <input type="text" class="form-control" placeholder="Search" aria-label="Search" name="search"
                aria-describedby="search-button">
            <button class="btn btn-outline-secondary" type="submit" id="search-button">Search</button>
        </div>
    </form>
</div>
<?php /**PATH /home/klark/Desktop/Files/Laravel Projects/2026/dinkinapp/resources/views/components/search-input.blade.php ENDPATH**/ ?>