<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-3">Tournament Name (<?php echo e($tournamentView->name); ?>)</h3>
                </div>
                
            </div>

            <div class="row">
                <div class="col-6 w-25">
                    <a href="<?php echo e(route('teams.create', ['tournament_id' => $tournamentView->id])); ?>" type="button"
                        class="btn btn-block btn-success mb-3">Add
                        Team +</a>
                </div>

            </div>

            <div class="card mb-4">

                <div class="card-header">

                    <div class="d-flex justify-content-between align-items-center">

                        <div>

                            <h5 class="mb-0">

                                <i class="fas fa-trophy"></i>

                                <?php echo e($tournamentView->name); ?>


                            </h5>

                        </div>


                        <div>

                            <a href="<?php echo e(route('tournament.index')); ?>" class="btn btn-sm btn-secondary">

                                <i class="fas fa-arrow-left"></i>

                                Back

                            </a>

                        </div>

                    </div>

                </div>

            </div>


            
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->

    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Teams List</h3>
                        </div>

                        <?php

                            $categories = collect();

                            foreach ($teamsGrouped as $bracket => $bracketCategories) {
                                foreach ($bracketCategories as $category => $teams) {
                                    $categories->push($category);
                                }
                            }

                            $categories = $categories->unique()->values();

                        ?>
                        <?php if($categories->count() > 0): ?>

                            <ul class="nav nav-tabs mb-4" id="categoryTabs" role="tablist">

                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php

                                        $categoryId = 'category-' . \Illuminate\Support\Str::slug($category);

                                    ?>

                                    <li class="nav-item" role="presentation">

                                        <button class="nav-link <?php echo e($loop->first ? 'active' : ''); ?>"
                                            id="<?php echo e($categoryId); ?>-tab" data-bs-toggle="tab"
                                            data-bs-target="#<?php echo e($categoryId); ?>" type="button" role="tab"
                                            aria-controls="<?php echo e($categoryId); ?>"
                                            aria-selected="<?php echo e($loop->first ? 'true' : 'false'); ?>">

                                            <i class="fas fa-users"></i>

                                            <?php echo e($category); ?>


                                        </button>

                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>

                            <div class="tab-content" id="categoryTabsContent">

                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php

                                        $categoryId = 'category-' . \Illuminate\Support\Str::slug($category);

                                    ?>


                                    <div class="tab-pane fade <?php echo e($loop->first ? 'show active' : ''); ?>"
                                        id="<?php echo e($categoryId); ?>" role="tabpanel"
                                        aria-labelledby="<?php echo e($categoryId); ?>-tab">

                                        <?php $__currentLoopData = $teamsGrouped; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bracket => $bracketCategories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(isset($bracketCategories[$category])): ?>
                                                <?php

                                                    $teams = $bracketCategories[$category];

                                                ?>

                                                <div class="card mb-4">
                                                    <div class="card-header">
                                                        <div class="d-flex justify-content-between align-items-center">
                                                            <div>
                                                                <strong>
                                                                    <i class="fas fa-layer-group"></i>
                                                                    Bracket <?php echo e($bracket); ?>

                                                                </strong>
                                                                <span class="badge bg-secondary ms-2">
                                                                    <?php echo e($teams->count()); ?>

                                                                    Teams
                                                                </span>
                                                            </div>
                                                            <div>
                                                                <a href="<?php echo e(route('tournament.matches.view', [
                                                                    'tournament_id' => Crypt::encryptString($tournamentView->id),
                                                                    'team_bracket' => $bracket,
                                                                    'team_category' => $category,
                                                                ])); ?>"
                                                                    class="btn btn-sm btn-info">
                                                                    <i class="fas fa-eye"></i>
                                                                    View Matches
                                                                </a>
                                                                <form
                                                                    action="<?php echo e(route('tournament.matches.generate', Crypt::encryptString($tournamentView->id))); ?>"
                                                                    method="POST" class="d-inline"
                                                                    onsubmit="return confirm(
                                                                        'Generate round robin matches for Bracket <?php echo e($bracket); ?> - <?php echo e($category); ?>?'
                                                                    );">
                                                                    <?php echo csrf_field(); ?>

                                                                    <input type="hidden" name="team_bracket"
                                                                        value="<?php echo e($bracket); ?>">

                                                                    <input type="hidden" name="team_category"
                                                                        value="<?php echo e($category); ?>">

                                                                    <button type="submit"
                                                                        class="btn btn-sm btn-primary">
                                                                        <i class="fas fa-random"></i>
                                                                        Generate Matches
                                                                    </button>
                                                                </form>
                                                            </div>

                                                        </div>

                                                    </div>

                                                    <div class="card-body">
                                                        <div class="table-responsive">
                                                            <table class="table table-bordered table-hover">
                                                                <thead>
                                                                    <tr>
                                                                        <th width="60">
                                                                            #
                                                                        </th>
                                                                        <th>
                                                                            Team No.
                                                                        </th>
                                                                        <th>
                                                                            Team Name
                                                                        </th>
                                                                        <th width="150">
                                                                            Action
                                                                        </th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__empty_1 = true; $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                        <tr>
                                                                            <td>
                                                                                <?php echo e($loop->iteration); ?>

                                                                            </td>
                                                                            <td>
                                                                                <?php echo e($team->team_no); ?>

                                                                            </td>
                                                                            <td>
                                                                                <?php echo e($team->team_name); ?>

                                                                            </td>
                                                                            <td>
                                                                                <div class="d-flex align-items-center"
                                                                                    style="gap: 5px;">

                                                                                    <a href="<?php echo e(route('teams.edit', Crypt::encryptString($team->id))); ?>"
                                                                                        class="btn btn-sm btn-warning">
                                                                                        <i class="fas fa-edit"
                                                                                            style="color: white;"></i>
                                                                                    </a>

                                                                                    <?php if (isset($component)) { $__componentOriginal2a28fb54575b01e7e2a3666792b68d45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a28fb54575b01e7e2a3666792b68d45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-delete-action','data' => ['id' => 'delete-team-'.e($team->id).'','style' => '','action' => ''.e(route('teams.destroy', Crypt::encryptString($team->id))).'','target' => 'deleteTeamConfirmationModal-'.e($team->id).'','idLabel' => 'deleteTeamModalLabel-'.e($team->id).'','labelBody' => 'Team Name: '.e($team->team_name).'','onClick' => 'submitTeamDeleteForm('.e($team->id).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-delete-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'delete-team-'.e($team->id).'','style' => '','action' => ''.e(route('teams.destroy', Crypt::encryptString($team->id))).'','target' => 'deleteTeamConfirmationModal-'.e($team->id).'','idLabel' => 'deleteTeamModalLabel-'.e($team->id).'','labelBody' => 'Team Name: '.e($team->team_name).'','onClick' => 'submitTeamDeleteForm('.e($team->id).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a28fb54575b01e7e2a3666792b68d45)): ?>
<?php $attributes = $__attributesOriginal2a28fb54575b01e7e2a3666792b68d45; ?>
<?php unset($__attributesOriginal2a28fb54575b01e7e2a3666792b68d45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a28fb54575b01e7e2a3666792b68d45)): ?>
<?php $component = $__componentOriginal2a28fb54575b01e7e2a3666792b68d45; ?>
<?php unset($__componentOriginal2a28fb54575b01e7e2a3666792b68d45); ?>
<?php endif; ?>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                                        <tr>
                                                                            <td colspan="4" class="text-center">
                                                                                No teams registered.
                                                                            </td>
                                                                        </tr>
                                                                    <?php endif; ?>
                                                                </tbody>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php else: ?>
                            <div class="card">

                                <div class="card-body text-center">

                                    <i class="fas fa-users fa-3x mb-3 text-muted"></i>

                                    <h5>
                                        No Teams Registered
                                    </h5>

                                    <p class="text-muted">
                                        There are currently no teams registered
                                        for this tournament.
                                    </p>


                                    

                                </div>

                            </div>

                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH /home/klark/Desktop/Files/Laravel Projects/2026/dinkinapp/resources/views/app/tournament/view.blade.php ENDPATH**/ ?>