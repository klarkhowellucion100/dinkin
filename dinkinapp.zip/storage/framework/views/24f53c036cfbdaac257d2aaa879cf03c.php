<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-3">Add Teams</h3>
                    
                </div>
                <!--end::Row-->
            </div>
            

            <div class="mb-3">
                <a href="<?php echo e(route('tournament.view', Crypt::encryptString($tournament->id))); ?>"
                    class="btn btn-block btn-success w-25">
                    <i class="fas fa-arrow-left"></i> Back
                </a>
            </div>


            <!--end::Container-->
        </div>
        <!--end::App Content Header-->
    </div>

    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Create Teams</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="col-xl-12 mt-4 p-3">
                            <form action="<?php echo e(route('teams.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('POST'); ?>
                                <div class="row">
                                    <input type="text" class="form-control" id="tournament_id" name="tournament_id"
                                        value="<?php echo e($tournament->id); ?>" hidden>

                                    <div class="col-md-3">
                                        <div class="form-floating mb-3">
                                            <label for="team_no">Team Number <span class="text-danger">*</span></label>
                                            <select class="form-control" id="team_no" name="team_no"
                                                aria-label="Team Number" required>

                                                <option value="" selected disabled>
                                                    Select Team Number...
                                                </option>

                                            </select>
                                            <script>
                                                const teamNoSelect = document.getElementById('team_no');

                                                for (let i = 1; i <= 1000; i++) {
                                                    const option = document.createElement('option');

                                                    option.value = `${String(i).padStart(2, '0')}`;
                                                    option.textContent = `${String(i).padStart(2, '0')}`;

                                                    teamNoSelect.appendChild(option);
                                                }
                                            </script>
                                        </div>
                                        <?php if (isset($component)) { $__componentOriginala0311668b84225c629d80adc067429fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0311668b84225c629d80adc067429fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-error','data' => ['name' => 'team_no']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'team_no']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0311668b84225c629d80adc067429fd)): ?>
<?php $attributes = $__attributesOriginala0311668b84225c629d80adc067429fd; ?>
<?php unset($__attributesOriginala0311668b84225c629d80adc067429fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0311668b84225c629d80adc067429fd)): ?>
<?php $component = $__componentOriginala0311668b84225c629d80adc067429fd; ?>
<?php unset($__componentOriginala0311668b84225c629d80adc067429fd); ?>
<?php endif; ?>
                                    </div>

                                    <?php if (isset($component)) { $__componentOriginal9dfb92df017b51f40463a6673afbaa92 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9dfb92df017b51f40463a6673afbaa92 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-input-list','data' => ['tList' => true,'style' => '','divClass' => 'col-md-9','type' => 'text','oninput' => '','inputLabel' => 'Team Name','forLabel' => 'team_name','placeHolder' => 'Team Name','id' => 'team_name','readonly' => '','value' => ''.e(old('team_name')).'','name' => 'team_name','list' => 'tournamentOptions']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-input-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['t-list' => true,'style' => '','divClass' => 'col-md-9','type' => 'text','oninput' => '','inputLabel' => 'Team Name','forLabel' => 'team_name','placeHolder' => 'Team Name','id' => 'team_name','readonly' => '','value' => ''.e(old('team_name')).'','name' => 'team_name','list' => 'tournamentOptions']); ?>
                                        <?php $__currentLoopData = $allTeams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($team->team_name); ?>">
                                                <?php echo e($team->team_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9dfb92df017b51f40463a6673afbaa92)): ?>
<?php $attributes = $__attributesOriginal9dfb92df017b51f40463a6673afbaa92; ?>
<?php unset($__attributesOriginal9dfb92df017b51f40463a6673afbaa92); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9dfb92df017b51f40463a6673afbaa92)): ?>
<?php $component = $__componentOriginal9dfb92df017b51f40463a6673afbaa92; ?>
<?php unset($__componentOriginal9dfb92df017b51f40463a6673afbaa92); ?>
<?php endif; ?>

                                    <div class="col-md-6">
                                        <div class="form-floating mb-3">
                                            <label for="bracket">
                                                Bracket <span class="text-danger">*</span>
                                            </label>
                                            <select class="form-control" id="team_bracket" name="team_bracket"
                                                aria-label="Bracket" required>

                                                <option value="" selected disabled>
                                                    Select Bracket...
                                                </option>
                                            </select>
                                            <script>
                                                const bracketSelect = document.getElementById('team_bracket');

                                                for (let i = 0; i < 26; i++) {
                                                    const letter = String.fromCharCode(65 + i);

                                                    const option = document.createElement('option');

                                                    option.value = letter;
                                                    option.textContent = `Bracket ${letter}`;

                                                    bracketSelect.appendChild(option);
                                                }
                                            </script>
                                        </div>
                                        <?php if (isset($component)) { $__componentOriginala0311668b84225c629d80adc067429fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0311668b84225c629d80adc067429fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-error','data' => ['name' => 'team_bracket']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'team_bracket']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0311668b84225c629d80adc067429fd)): ?>
<?php $attributes = $__attributesOriginala0311668b84225c629d80adc067429fd; ?>
<?php unset($__attributesOriginala0311668b84225c629d80adc067429fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0311668b84225c629d80adc067429fd)): ?>
<?php $component = $__componentOriginala0311668b84225c629d80adc067429fd; ?>
<?php unset($__componentOriginala0311668b84225c629d80adc067429fd); ?>
<?php endif; ?>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-floating mb-3">
                                            <label for="team_category">
                                                Team Category <span class="text-danger">*</span>
                                            </label>
                                            <select class="form-control" id="team_category" name="team_category"
                                                aria-label="Team Category" required>

                                                <option value="" selected disabled>
                                                    Select Team Category...
                                                </option>
                                                <option value="Low Beginners">
                                                    Low Beginners
                                                </option>
                                                <option value="High Beginners">
                                                    High Beginners
                                                </option>
                                                <option value="Low Novice">
                                                    Low Novice
                                                </option>
                                                <option value="High Novice">
                                                    High Novice
                                                </option>
                                                <option value="Low Intermediate">
                                                    Low Intermediate
                                                </option>
                                                <option value="High Intermediate">
                                                    High Intermediate
                                                </option>
                                                <option value="Open">
                                                    Open
                                                </option>
                                            </select>

                                        </div>
                                        <?php if (isset($component)) { $__componentOriginala0311668b84225c629d80adc067429fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0311668b84225c629d80adc067429fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-error','data' => ['name' => 'team_category']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'team_category']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0311668b84225c629d80adc067429fd)): ?>
<?php $attributes = $__attributesOriginala0311668b84225c629d80adc067429fd; ?>
<?php unset($__attributesOriginala0311668b84225c629d80adc067429fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0311668b84225c629d80adc067429fd)): ?>
<?php $component = $__componentOriginala0311668b84225c629d80adc067429fd; ?>
<?php unset($__componentOriginala0311668b84225c629d80adc067429fd); ?>
<?php endif; ?>
                                    </div>
                                    

                                </div>
                                <div class="d-flex flex-wrap gap-3">
                                    <?php if (isset($component)) { $__componentOriginalbb660c7d3380b22758129b879204cbaa = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalbb660c7d3380b22758129b879204cbaa = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-button','data' => ['btnType' => 'submit','btnAddClass' => 'btn-primary','fdprocessedid' => 'swuiv','btnLabel' => 'Create']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['btnType' => 'submit','btnAddClass' => 'btn-primary','fdprocessedid' => 'swuiv','btnLabel' => 'Create']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalbb660c7d3380b22758129b879204cbaa)): ?>
<?php $attributes = $__attributesOriginalbb660c7d3380b22758129b879204cbaa; ?>
<?php unset($__attributesOriginalbb660c7d3380b22758129b879204cbaa); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbb660c7d3380b22758129b879204cbaa)): ?>
<?php $component = $__componentOriginalbb660c7d3380b22758129b879204cbaa; ?>
<?php unset($__componentOriginalbb660c7d3380b22758129b879204cbaa); ?>
<?php endif; ?>
                                </div>
                            </form>
                        </div>
                        <!-- end col -->
                    </div>
                    <!-- /.card --->
                </div>
                <!-- /.col -->
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH /home/klark/Desktop/Files/Laravel Projects/2026/dinkinapp/resources/views/app/tournament/teams/create.blade.php ENDPATH**/ ?>