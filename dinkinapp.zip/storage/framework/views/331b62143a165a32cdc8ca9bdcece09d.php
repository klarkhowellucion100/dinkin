<div class="<?php echo e($divClass); ?>" style="<?php echo e($style); ?>">
    <div class="form-group mb-3">
        <label for="<?php echo e($forLabel); ?>"><?php echo e($inputLabel); ?></label>
        <input type="<?php echo e($type); ?>" class="form-control" id="<?php echo e($id); ?>" placeholder="<?php echo e($placeHolder); ?>"
            list="<?php echo e($list); ?>" oninput="<?php echo e($oninput); ?>" fdprocessedid="3s3mk" name="<?php echo e($name); ?>"
            value="<?php echo e($value); ?>" <?php echo e($readonly ? 'readonly' : ''); ?>>
    </div>
    <datalist id=<?php echo e($list); ?>>
        <?php echo e($slot); ?>

    </datalist>
    <?php if (isset($component)) { $__componentOriginala0311668b84225c629d80adc067429fd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0311668b84225c629d80adc067429fd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-error','data' => ['name' => ''.e($name).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => ''.e($name).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0311668b84225c629d80adc067429fd)): ?>
<?php $attributes = $__attributesOriginala0311668b84225c629d80adc067429fd; ?>
<?php unset($__attributesOriginala0311668b84225c629d80adc067429fd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0311668b84225c629d80adc067429fd)): ?>
<?php $component = $__componentOriginala0311668b84225c629d80adc067429fd; ?>
<?php unset($__componentOriginala0311668b84225c629d80adc067429fd); ?>
<?php endif; ?>
</div>
<?php /**PATH /home/klark/Desktop/Files/Laravel Projects/2026/dinkinapp/resources/views/components/form-input-list.blade.php ENDPATH**/ ?>