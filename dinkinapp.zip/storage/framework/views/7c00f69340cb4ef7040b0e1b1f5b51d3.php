<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!--begin::App Content Header-->
    <div class="app-content-header">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-sm-6">
                    <h3 class="mb-3">Tournament</h3>
                </div>
                
            </div>


            <a href="<?php echo e(route('tournament.create')); ?>" type="button" class="btn btn-block btn-success w-25">Add
                +</a>

            <?php if (isset($component)) { $__componentOriginal1c4b45f62348de9b6fa41ee823d3fa96 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1c4b45f62348de9b6fa41ee823d3fa96 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-input','data' => ['formAction' => ''.e(route('tournament.search')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['formAction' => ''.e(route('tournament.search')).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1c4b45f62348de9b6fa41ee823d3fa96)): ?>
<?php $attributes = $__attributesOriginal1c4b45f62348de9b6fa41ee823d3fa96; ?>
<?php unset($__attributesOriginal1c4b45f62348de9b6fa41ee823d3fa96); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1c4b45f62348de9b6fa41ee823d3fa96)): ?>
<?php $component = $__componentOriginal1c4b45f62348de9b6fa41ee823d3fa96; ?>
<?php unset($__componentOriginal1c4b45f62348de9b6fa41ee823d3fa96); ?>
<?php endif; ?>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content Header-->

    <div class="app-content">
        <!--begin::Container-->
        <div class="container-fluid">
            <!--begin::Row-->
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Tournament List</h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Tournament</th>
                                        <th>Date</th>
                                        <th>Venue</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $allTournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($tournament->name); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::parse($tournament->date)->format('M d, Y')); ?></td>
                                            <td><?php echo e($tournament->venue); ?></td>
                                            <td>
                                                <div class="d-flex align-items-center" style="gap: 5px;">
                                                    <a href="<?php echo e(route('tournament.view', Crypt::encryptString($tournament->id))); ?>"
                                                        class="btn btn-sm btn-success">
                                                        <i class="fas fa-eye" style="color: white"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('tournament.edit', Crypt::encryptString($tournament->id))); ?>"
                                                        class="btn btn-sm btn-warning">
                                                        <i class="fas fa-edit fa-solid fa-edit"
                                                            style="color: white"></i>
                                                    </a>
                                                    <?php if (isset($component)) { $__componentOriginal2a28fb54575b01e7e2a3666792b68d45 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a28fb54575b01e7e2a3666792b68d45 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form-delete-action','data' => ['id' => 'delete-tournament-'.e($tournament->id).'','style' => '','action' => ''.e(route('tournament.destroy', Crypt::encryptString($tournament->id))).'','target' => 'deleteTournamentConfirmationModal-'.e($tournament->id).'','idLabel' => 'deleteTournamentModalLabel-'.e($tournament->id).'','labelBody' => 'Tournament Name: '.e($tournament->name).'','onClick' => 'submitTournamentDeleteForm('.e($tournament->id).')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form-delete-action'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'delete-tournament-'.e($tournament->id).'','style' => '','action' => ''.e(route('tournament.destroy', Crypt::encryptString($tournament->id))).'','target' => 'deleteTournamentConfirmationModal-'.e($tournament->id).'','idLabel' => 'deleteTournamentModalLabel-'.e($tournament->id).'','labelBody' => 'Tournament Name: '.e($tournament->name).'','onClick' => 'submitTournamentDeleteForm('.e($tournament->id).')']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a28fb54575b01e7e2a3666792b68d45)): ?>
<?php $attributes = $__attributesOriginal2a28fb54575b01e7e2a3666792b68d45; ?>
<?php unset($__attributesOriginal2a28fb54575b01e7e2a3666792b68d45); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a28fb54575b01e7e2a3666792b68d45)): ?>
<?php $component = $__componentOriginal2a28fb54575b01e7e2a3666792b68d45; ?>
<?php unset($__componentOriginal2a28fb54575b01e7e2a3666792b68d45); ?>
<?php endif; ?>
                                                </div>
                                            </td>
                                            </td>
                                            <script>
                                                function submitTournamentDeleteForm(id) {
                                                    // This now correctly finds "delete-tournament-1"
                                                    const form = document.getElementById('delete-tournament-' + id);
                                                    if (form) {
                                                        form.submit();
                                                    }
                                                }
                                            </script>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="3" class="text-center">No tournaments found.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer clearfix">
                            <ul class="pagination pagination-sm m-0 float-end">
                                <div>
                                    <div class="mt-3">
                                        <?php echo e($allTournaments->appends(['search' => request()->input('search')])->links()); ?>

                                    </div>
                                </div>
                            </ul>
                        </div>
                    </div>
                    <!-- /.card --->
                </div>
                <!-- /.col -->
            </div>
            <!--end::Row-->
        </div>
        <!--end::Container-->
    </div>
    <!--end::App Content-->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH /home/klark/Desktop/Files/Laravel Projects/2026/dinkinapp/resources/views/app/tournament/index.blade.php ENDPATH**/ ?>