<form id="<?php echo e($id); ?>" action="<?php echo e($action); ?>" method="POST" style="<?php echo e($style); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <!-- Trigger Modal -->
    <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#<?php echo e($target); ?>">
        <i class="fas fa-trash fa-solid" style="color: white"></i>
    </button>
</form>

<!-- Start Delete Modal -->
<div class="modal fade" id="<?php echo e($target); ?>" tabindex="-1" aria-labelledby="<?php echo e($idLabel); ?>"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="<?php echo e($idLabel); ?>">
                    Confirm
                    Deletion</h5>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this <?php echo e($labelBody); ?>?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                <button type="button" class="btn btn-danger"
                    onclick="document.getElementById('<?php echo e($id); ?>').submit()">Yes</button>
            </div>
        </div>
    </div>
</div>
<!-- End Delete Modal -->
<?php /**PATH /home/klark/Desktop/Files/Laravel Projects/2026/dinkinapp/resources/views/components/form-delete-action.blade.php ENDPATH**/ ?>