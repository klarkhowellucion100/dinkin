<?php if (isset($component)) { $__componentOriginal66d7cfd03cd343304d81fe1e21646540 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal66d7cfd03cd343304d81fe1e21646540 = $attributes; } ?>
<?php $component = App\View\Components\MainLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('main-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MainLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="container-fluid">

        
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="h3 mb-1 font-weight-bold">
                    Tournament Dashboard
                </h1>
                <p class="text-muted mb-0">
                    Pickleball Tournament Management System
                </p>
            </div>

            <div>
                <a href="<?php echo e(route('tournament.create')); ?>" class="btn btn-primary">
                    <i class="fas fa-plus"></i>
                    New Tournament
                </a>
            </div>
        </div>


        
        <div class="row">

            <div class="col-lg-3 col-md-6">
                <div class="card card-primary shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <div class="text-muted text-uppercase small">
                                    Tournaments
                                </div>

                                <h2 class="font-weight-bold mb-0">
                                    <?php echo e($totalTournaments); ?>

                                </h2>
                            </div>

                            <div class="text-primary">
                                <i class="fas fa-trophy fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-3 col-md-6">
                <div class="card card-success shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <div class="text-muted text-uppercase small">
                                    Teams Registered
                                </div>

                                <h2 class="font-weight-bold mb-0">
                                    <?php echo e($totalTeams); ?>

                                </h2>
                            </div>

                            <div class="text-success">
                                <i class="fas fa-users fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-3 col-md-6">
                <div class="card card-info shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <div class="text-muted text-uppercase small">
                                    Matches Completed
                                </div>

                                <h2 class="font-weight-bold mb-0">
                                    <?php echo e($completedMatches); ?>

                                </h2>
                            </div>

                            <div class="text-info">
                                <i class="fas fa-check-circle fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="col-lg-3 col-md-6">
                <div class="card card-warning shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between">
                            <div>
                                <div class="text-muted text-uppercase small">
                                    Matches Pending
                                </div>

                                <h2 class="font-weight-bold mb-0">
                                    <?php echo e($pendingMatches); ?>

                                </h2>
                            </div>

                            <div class="text-warning">
                                <i class="fas fa-clock fa-2x"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>


        
        <div class="row">

            
            <div class="col-lg-6">
                <div class="card shadow-sm h-100">

                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-calendar-alt mr-2"></i>
                            Upcoming Tournament
                        </h3>
                    </div>

                    <div class="card-body">

                        <?php if($upcomingTournament): ?>
                            <h4 class="font-weight-bold">
                                <?php echo e($upcomingTournament->name); ?>

                            </h4>

                            <p class="text-muted mb-2">
                                <i class="fas fa-calendar mr-1"></i>
                                <?php echo e(\Carbon\Carbon::parse($upcomingTournament->date)->format('F d, Y')); ?>

                            </p>

                            <p class="text-muted mb-3">
                                <i class="fas fa-map-marker-alt mr-1"></i>
                                <?php echo e($upcomingTournament->venue); ?>

                            </p>

                            <a href="<?php echo e(route('tournament.view', Crypt::encryptString($upcomingTournament->id))); ?>"
                                class="btn btn-primary btn-sm">
                                Manage Tournament
                            </a>
                        <?php else: ?>
                            <div class="text-center py-4">
                                <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>

                                <p class="text-muted mb-3">
                                    No upcoming tournaments.
                                </p>

                                <a href="<?php echo e(route('tournament.create')); ?>" class="btn btn-primary btn-sm">
                                    Create Tournament
                                </a>
                            </div>
                        <?php endif; ?>

                    </div>
                </div>
            </div>


            
            <div class="col-lg-6">
                <div class="card shadow-sm h-100">

                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-chart-line mr-2"></i>
                            Match Progress
                        </h3>
                    </div>

                    <div class="card-body">

                        <div class="d-flex justify-content-between mb-2">
                            <span>
                                Overall Completion
                            </span>

                            <strong>
                                <?php echo e($matchProgress); ?>%
                            </strong>
                        </div>

                        <div class="progress mb-4" style="height: 12px;">
                            <div class="progress-bar bg-success" role="progressbar"
                                style="width: <?php echo e($matchProgress); ?>%;"></div>
                        </div>

                        <div class="row text-center">

                            <div class="col-4">
                                <h4 class="font-weight-bold text-primary">
                                    <?php echo e($totalMatches); ?>

                                </h4>
                                <small class="text-muted">
                                    Round Robin
                                </small>
                            </div>

                            <div class="col-4">
                                <h4 class="font-weight-bold text-success">
                                    <?php echo e($completedMatches); ?>

                                </h4>
                                <small class="text-muted">
                                    Completed
                                </small>
                            </div>

                            <div class="col-4">
                                <h4 class="font-weight-bold text-warning">
                                    <?php echo e($pendingMatches); ?>

                                </h4>
                                <small class="text-muted">
                                    Pending
                                </small>
                            </div>

                        </div>

                    </div>
                </div>
            </div>

        </div>


        
        <div class="row">

            
            <div class="col-lg-8">

                <div class="card shadow-sm">

                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-table-tennis-paddle-ball mr-2"></i>
                            Recent Match Results
                        </h3>

                        <div class="card-tools">
                            <a href="<?php echo e(route('public.tournaments')); ?>" class="btn btn-sm btn-outline-primary"
                                target="_blank">
                                <i class="fas fa-external-link-alt mr-1"></i>
                                Public Results
                            </a>
                        </div>
                    </div>

                    <div class="card-body p-0">

                        <div class="table-responsive">

                            <table class="table table-hover mb-0">

                                <thead class="thead-light">
                                    <tr>
                                        <th>Match</th>
                                        <th>Teams</th>
                                        <th>Score</th>
                                        <th>Winner</th>
                                    </tr>
                                </thead>

                                <tbody>

                                    <?php $__empty_1 = true; $__currentLoopData = $recentMatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>

                                            <td>
                                                <span class="badge badge-secondary">
                                                    R<?php echo e($match->round_no); ?>

                                                    -
                                                    M<?php echo e($match->match_no); ?>

                                                </span>
                                            </td>

                                            <td>
                                                <strong>
                                                    <?php echo e($match->team1_no); ?>

                                                </strong>
                                                <?php echo e($match->team1_name); ?>


                                                <br>

                                                <strong>
                                                    <?php echo e($match->team2_no); ?>

                                                </strong>
                                                <?php echo e($match->team2_name); ?>

                                            </td>

                                            <td>
                                                <strong>
                                                    <?php echo e($match->team1_score); ?>

                                                    -
                                                    <?php echo e($match->team2_score); ?>

                                                </strong>
                                            </td>

                                            <td>
                                                <?php if($match->winner_name): ?>
                                                    <span class="badge badge-success">
                                                        <?php echo e($match->winner_no); ?>

                                                    </span>

                                                    <?php echo e($match->winner_name); ?>

                                                <?php else: ?>
                                                    <span class="text-muted">
                                                        Pending
                                                    </span>
                                                <?php endif; ?>
                                            </td>

                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <tr>
                                            <td colspan="4" class="text-center text-muted py-4">
                                                No match results available.
                                            </td>
                                        </tr>
                                    <?php endif; ?>

                                </tbody>

                            </table>

                        </div>

                    </div>
                </div>

            </div>


            
            <div class="col-lg-4">

                <div class="card shadow-sm">

                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-layer-group mr-2"></i>
                            Team Categories
                        </h3>
                    </div>

                    <div class="card-body">

                        <?php $__empty_1 = true; $__currentLoopData = $categorySummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="d-flex justify-content-between align-items-center mb-3">

                                <div>
                                    <strong>
                                        <?php echo e($category->team_category); ?>

                                    </strong>

                                    <br>

                                    <small class="text-muted">
                                        <?php echo e($category->team_count); ?> teams
                                    </small>
                                </div>

                                <span class="badge badge-primary">
                                    <?php echo e($category->team_count); ?>

                                </span>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <p class="text-muted text-center mb-0">
                                No team categories available.
                            </p>
                        <?php endif; ?>

                    </div>

                </div>


                
                <div class="card shadow-sm">

                    <div class="card-header">
                        <h3 class="card-title">
                            <i class="fas fa-bolt mr-2"></i>
                            Quick Actions
                        </h3>
                    </div>

                    <div class="card-body">

                        <a href="<?php echo e(route('tournament.create')); ?>" class="btn btn-primary btn-block">
                            <i class="fas fa-plus mr-1"></i>
                            Create Tournament
                        </a>

                        <a href="<?php echo e(route('tournament.index')); ?>" class="btn btn-outline-secondary btn-block">
                            <i class="fas fa-list mr-1"></i>
                            Manage Tournaments
                        </a>

                        <a href="<?php echo e(route('public.tournaments')); ?>" class="btn btn-outline-success btn-block"
                            target="_blank">
                            <i class="fas fa-tv mr-1"></i>
                            Open Live Results
                        </a>

                    </div>

                </div>

            </div>

        </div>


        
        <div class="card shadow-sm">

            <div class="card-header">
                <h3 class="card-title">
                    <i class="fas fa-history mr-2"></i>
                    Recent Tournaments
                </h3>
            </div>

            <div class="card-body p-0">

                <div class="table-responsive">

                    <table class="table table-hover mb-0">

                        <thead class="thead-light">
                            <tr>
                                <th>Tournament</th>
                                <th>Date</th>
                                <th>Venue</th>
                                <th>Teams</th>
                                <th>Progress</th>
                                <th></th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php $__empty_1 = true; $__currentLoopData = $recentTournaments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tournament): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>

                                    <td>
                                        <strong>
                                            <?php echo e($tournament->name); ?>

                                        </strong>
                                    </td>

                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($tournament->date)->format('M d, Y')); ?>

                                    </td>

                                    <td>
                                        <?php echo e($tournament->venue); ?>

                                    </td>

                                    <td>
                                        <span class="badge badge-primary">
                                            <?php echo e($tournament->team_count); ?>

                                        </span>
                                    </td>

                                    <td style="min-width: 150px;">

                                        <div class="d-flex justify-content-between">
                                            <small>
                                                <?php echo e($tournament->completed_matches); ?>

                                                /
                                                <?php echo e($tournament->total_matches); ?>

                                            </small>

                                            <small>
                                                <?php echo e($tournament->progress); ?>%
                                            </small>
                                        </div>

                                        <div class="progress" style="height: 6px;">
                                            <div class="progress-bar bg-success"
                                                style="width: <?php echo e($tournament->progress); ?>%;"></div>
                                        </div>

                                    </td>

                                    <td class="text-right">

                                        <a href="<?php echo e(route('tournament.view', Crypt::encryptString($tournament->id))); ?>"
                                            class="btn btn-sm btn-outline-primary">
                                            View
                                        </a>

                                    </td>

                                </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">
                                        No tournaments available.
                                    </td>
                                </tr>
                            <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $attributes = $__attributesOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__attributesOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal66d7cfd03cd343304d81fe1e21646540)): ?>
<?php $component = $__componentOriginal66d7cfd03cd343304d81fe1e21646540; ?>
<?php unset($__componentOriginal66d7cfd03cd343304d81fe1e21646540); ?>
<?php endif; ?>
<?php /**PATH /home/klark/Desktop/Files/Laravel Projects/2026/dinkinapp/resources/views/dashboard.blade.php ENDPATH**/ ?>