<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<style>
    .status-box {
        margin-bottom: 15px;
        padding: 10px 12px;
        border-radius: 10px;
        font-size: 0.85rem;
        font-weight: 500;
        color: #22c55e;
        background: rgba(34, 197, 94, 0.1);
        border: 1px solid rgba(34, 197, 94, 0.3);
        backdrop-filter: blur(8px);
    }
</style>

<?php if($status): ?>
    <div <?php echo e($attributes->merge(['class' => 'status-box'])); ?>>
        <?php echo e($status); ?>

    </div>
<?php endif; ?>
<?php /**PATH /home/klark/Desktop/Files/Laravel Projects/2026/dinkinapp/resources/views/components/auth-session-status.blade.php ENDPATH**/ ?>