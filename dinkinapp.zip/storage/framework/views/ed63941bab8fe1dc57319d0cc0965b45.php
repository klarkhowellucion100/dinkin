<button type="<?php echo e($btnType); ?>" class="btn <?php echo e($btnAddClass); ?> waves-effect waves-light w-md"
    fdprocessedid="swuiv"><?php echo e($btnLabel); ?></button>
<?php /**PATH /home/klark/Desktop/Files/Laravel Projects/2026/dinkinapp/resources/views/components/form-button.blade.php ENDPATH**/ ?>