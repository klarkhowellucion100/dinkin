<div class="mb-3">
    <a href="<?php echo e(route($route)); ?>" class="btn btn-block btn-success w-25">
        <i class="fas fa-arrow-left"></i> Back
    </a>
</div>
<?php /**PATH /home/klark/Desktop/Files/Laravel Projects/2026/dinkinapp/resources/views/components/back-button.blade.php ENDPATH**/ ?>